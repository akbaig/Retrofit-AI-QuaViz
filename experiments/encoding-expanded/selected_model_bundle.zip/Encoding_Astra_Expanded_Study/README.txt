ENCODING ASTRA — EXPANDED STUDY

Selected model: a separate 32D neural encoder plus logistic regression for each of seven engineering template families. Fresh-test ANY_FAULT AP: 0.869. Read REPORT.md and EXPERIMENT_README.md for comparisons, tradeoffs and reproduction.

This compact bundle contains the seven selected inference models, necessary inference code, and complete CSV/JSON comparison results. It does not contain the training recordings, prepared caches, every comparison model, or every prediction Parquet. The full experiment remains in the local encoding-astra checkout. Frozen receipts in results retain the original local paths for audit.

Install Python 3.12 and requirements.txt, then run from this folder:

python experiments/encoding-expanded/infer.py --model models/PUMP-01.joblib --data-dir /path/to/observations --asset-id YOUR_RECORDING --readout logistic --output /tmp/fault-scores.parquet

Choose the model matching template_asset_id in assets.csv. Original PUMP-01 through PUMP-07 may use their own asset IDs. Required observation files: assets.csv, features_1min.parquet, operating_context.csv, vibration_snapshots.parquet. No events file is read. Optional --until accepts a UTC timestamp. past_warmup marks minutes beyond the initial two hours.

Outputs are per-minute uncalibrated fault scores and decisions, not official challenge alert submissions. These models were tested on fresh recordings from known synthetic equipment families; they have not been validated on real pumps or unknown equipment families.

Compact export removed unused nearest-neighbor and boosted-tree readouts. All selected classifier/encoder parameters were preserved; 100 heldout rows per family replayed identically. See MODEL_BUNDLE_VERIFICATION.json.
